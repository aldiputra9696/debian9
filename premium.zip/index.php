<title>Installer SSH & VPN Cara-Aldi.COM</title>
Instalation SSH Installer
<br><br>
Fitur SSH & OVPN<br>
wget https://raw.githubusercontent.com/aldiputra9696/sshscript/main/Deb9 && chmod +x Deb9 && ./Deb9<br>
OR<br>
wget https://ssh.premium.cara-aldi.com/Deb9.sh && chmod +x Deb9.sh && ./Deb9.sh<br>
<br><br>
Fitur SSH,OVPN,dan PPTP<br>
Coming Soon<br>
Pakai System Operasi Debian 9